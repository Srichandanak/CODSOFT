
# A function to add two numbers
def add(x, y):
    return x + y
# A function to perform subtraction between two numbers
def subtract(x, y):
    return x - y
# A function to multiply two numbers
def multiply(x, y):
    return x * y
# A function to perform division between two numbers
def divide(x, y):
    if y != 0:
        return x / y
    #zeroerror
    else:
        return "Sorry! Denominator cannot be zero.! "
#main method - fist display choices 
def main():
    print("*************Welcome to Simple Calculator Application**************")
    print("-------------------------------MENU--------------------------------")
    print("Press 1 to Add")
    print("Press 2 to Subtract")
    print("Press 3 to Multiply")
    print("Press 4 to Divide")
    print("Press 5 to enter calculation")

    while True:
        ch = input("Enter choice (1/2/3/4): ")
        
        # for choices 1 - 4 only input is 'two numbers'
        if ch in ['1', '2', '3', '4']:
            try:
                n1 = float(input("Enter first number: "))
                n2 = float(input("Enter second number: "))
            except ValueError:
                print("Invalid input. Please enter numeric values.")
                continue

            if ch == '1':
                sumans = add(n1, n2)
                print(f"The sum of {n1} and {n2} is: {sumans}")
            elif ch == '2':
                diff = subtract(n1, n2)
                print(f"The difference of {n1} and {n2} is: {diff}")
            elif ch == '3':
                prod = multiply(n1, n2)
                print(f"The product of {n1} and {n2} is: {prod}")
            elif ch == '4':
                quo = divide(n1, n2)
                print(f"The resultof {n1} and {n2} is: {quo}")
        elif ch == '5':
            try:
            #input can be a string of operands and operators in a sequence    
                operations = input("Enter the sequence of operations (e.g., number operator number operator number) spaces are necessary: ")
                # Split operations by spaces and iterate through them
                operations = operations.split()
                #initialize result with 1st number 
                result = float(operations[0]) 
                i = 1
                while i < len(operations):
                    op = operations[i]
                    num = float(operations[i + 1])
                    #the answer of previous operation is given to result
                    if op == '+':
                        result = add(result, num)
                    elif op == '-':
                        result = subtract(result, num)
                    elif op == '*':
                        result = multiply(result, num)
                    elif op == '/':
                        result = divide(result, num)
                    i += 2 
                    # Move to the next operator and number as there is a space 
                print(f"The result of the sequence {operations} is: {result}")

            except (ValueError, IndexError):
                print("Invalid input for sequence of operations.")
                
            proceed = input("Do you want to perform one more calculation? YES/NO: ")
            if proceed.lower() != 'yes':
                break
        else:
            print("Invalid Input")

if __name__ == "__main__":
    main()
