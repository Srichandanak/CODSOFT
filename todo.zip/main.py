#Create a class so that we can define all the functions of to do list here
class ToDoList:
    #creating a constructor list(like array)
    def __init__(self):
        self.tasks = []
    #to add task to do
    def add_task(self, task):
        self.tasks.append({"task": task, "completed": False})
    #to remove tasks from the list
    def delete_task(self, num):
        if 0 <= num < len(self.tasks):
            del self.tasks[num]
        else:
            print("Invalid task number.")
    #to check what are the remaining tasks
    def view_tasks(self):
        if not self.tasks:
            print("No tasks in the list.")
        for i, task in enumerate(self.tasks):
            status = "Completed" if task["completed"] else "Not Completed"
            print(f"{i + 1}. {task['task']} is {status}")
    #to mark as done
    def mark_task_completed(self, num):
        if 0 <= num < len(self.tasks):
            self.tasks[num]["completed"] = True
        else:
            print("Invalid task number.")

def main():
    #to Create an instance (object) to do list
    todo_list = ToDoList()
    #Menu
    while True:
        print("\n************Welcome to your TO-DO LIST***********")
        print("Press 1 to Add a task to your TO-DO LIST")
        print("Press 2 to Delete a task from your TO-DO LIST")
        print("Press 3 to View tasks in your TO-DO LIST")
        print("Press 4 to Mark any task as Completed")
        print("Press 5 to Exit your TO-DO LIST")

        choice = input("Enter your choice: ")

        if choice == '1':
            task = input("Enter the task to be added: ")
            todo_list.add_task(task)
        elif choice == '2':
            num = int(input("Enter the task number to be deleted: ")) - 1
            todo_list.delete_task(num)
        elif choice == '3':
            todo_list.view_tasks()
        elif choice == '4':
            num = int(input("Enter the task number to mark as completed: ")) - 1
            todo_list.mark_task_completed(num)
        elif choice == '5':
            break
        else:
            print("Sorry!!! Please try again with a valid choice..!")

if __name__ == "__main__":
    main()
